const express = require('express');
const session = require('express-session');
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const PORT = process.env.PORT || 3000;
const GROUP_LINK = process.env.GROUP_LINK || '';

if (!BOT_TOKEN || !ADMIN_PASSWORD || !SESSION_SECRET) {
  console.error('Missing BOT_TOKEN, ADMIN_PASSWORD, or SESSION_SECRET environment variable.');
  process.exit(1);
}

const app = express();
app.use(express.json({limit:'100kb'}));
app.use(express.urlencoded({extended:false}));
app.use(session({
  name: 'postino.sid',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 8*60*60*1000 }
}));

const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
function loadUsers() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
  catch { return {}; }
}
let users = loadUsers();
function saveUsers() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(users, null, 2), { mode: 0o600 });
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
bot.onText(/^\/start(?:@\w+)?$/, async (msg) => {
  const chatId = String(msg.chat.id);
  await bot.sendMessage(chatId,
    'سلام! به ربات دعوت پوستینو خوش اومدی. اگر مایل هستی پیام‌های دعوت گروه را دریافت کنی، رضایتت را با دکمه زیر ثبت کن. هر زمان خواستی می‌توانی با /stop لغو کنی.',
    { reply_markup: { inline_keyboard: [[{ text: 'بله، مایلم دعوت دریافت کنم', callback_data: 'consent_yes' }]] } }
  );
});
bot.on('callback_query', async (q) => {
  const chatId = String(q.message.chat.id);
  if (q.data === 'consent_yes') {
    users[chatId] = { chatId, username: q.from.username || '', firstName: q.from.first_name || '', consent: true, joinedAt: new Date().toISOString() };
    saveUsers();
    await bot.answerCallbackQuery(q.id, { text: 'رضایت شما ثبت شد.' });
    await bot.sendMessage(chatId, 'ممنون! رضایت شما ثبت شد. برای لغو دریافت پیام‌ها هر زمان /stop را بفرست.');
  }
});
bot.onText(/^\/stop(?:@\w+)?$/, async (msg) => {
  const id = String(msg.chat.id);
  if (users[id]) { delete users[id]; saveUsers(); }
  await bot.sendMessage(id, 'دریافت پیام‌های دعوت لغو شد. اگر بعداً خواستی دوباره ثبت‌نام کنی /start را بفرست.');
});
bot.on('polling_error', e => console.error('Telegram polling error:', e.message));

function requireAuth(req, res, next) {
  if (req.session && req.session.authed) return next();
  return res.status(401).json({ error: 'ابتدا وارد پنل شوید.' });
}
app.get('/health', (req,res) => res.json({ok:true}));
app.get('/api/config', requireAuth, (req,res) => res.json({ groupLink: GROUP_LINK }));
app.post('/api/login', (req,res) => {
  if (typeof req.body.password !== 'string' || req.body.password !== ADMIN_PASSWORD) {
    return res.status(401).json({error:'رمز عبور اشتباه است.'});
  }
  req.session.authed = true;
  res.json({ok:true});
});
app.post('/api/logout', requireAuth, (req,res) => req.session.destroy(() => res.json({ok:true})));
app.get('/api/stats', requireAuth, (req,res) => {
  const list = Object.values(users).filter(u => u.consent);
  res.json({total:list.length, users:list.map(u=>({username:u.username, firstName:u.firstName, joinedAt:u.joinedAt}))});
});
app.post('/api/send', requireAuth, async (req,res) => {
  const text = String(req.body.text || '').trim();
  if (!text) return res.status(400).json({error:'متن پیام را وارد کنید.'});
  if (text.length > 3500) return res.status(400).json({error:'متن پیام خیلی طولانی است.'});
  const recipients = Object.values(users).filter(u => u.consent);
  let sent = 0, failed = 0;
  for (const u of recipients) {
    try {
      await bot.sendMessage(u.chatId, text, { disable_web_page_preview: false });
      sent++;
    } catch (e) {
      failed++;
      console.error('Send failed for chat', u.chatId, e.message);
      if (e.response && e.response.statusCode === 403) {
        delete users[u.chatId];
      }
    }
    await new Promise(resolve => setTimeout(resolve, 450));
  }
  saveUsers();
  res.json({sent, failed, total:recipients.length});
});
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req,res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`Postino panel listening on ${PORT}`));
